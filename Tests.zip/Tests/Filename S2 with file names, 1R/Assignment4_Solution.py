
import argparse
import sys

import numpy as np
import pandas as pd
    

def read_all_files():
    
    try:
        
        """
        parser = argparse.ArgumentParser()
        parser.add_argument("player1boardfilename", help="board information for player 1", type=str)
        parser.add_argument("player2boardfilename", help="board information for player 2", type=str)
        parser.add_argument("player1inputfilename", help="player 2 move information", type=str)
        parser.add_argument("player2inputfilename", help="player 2 move information", type=str)
        
        args = parser.parse_args()
        """
        
        Player1_txt = "Player1.txt"
        Player2_txt = "Player2.txt"
        Player1_in = "Player1.in"
        Player2_in = "Player2.in"
        
        P1_optional = "OptionalPlayer1.txt"
        P2_optional = "OptionalPlayer2.txt"
        
        print(sys.argv[1]) # arg1
        print(sys.argv[2]) # arg2
        print(sys.argv[3]) # arg3
        print(sys.argv[4]) # arg3
        
        Player1_txt = sys.argv[1]
        Player2_txt = sys.argv[2]
        Player1_in = sys.argv[3]
        Player2_in = sys.argv[4]
        

    except Exception as e:
        print(e)
    
    
    col_names = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J"]
    
    Player1_txt_df = pd.read_csv(Player1_txt, header=None, delimiter=";", names = col_names)
    Player1_txt_df.index = np.arange(1,11)
    Player1_txt_df = Player1_txt_df.fillna("-")
    
    Player2_txt_df = pd.read_csv(Player2_txt, header=None, delimiter=";", names = col_names)
    Player2_txt_df.index = np.arange(1,11)
    Player2_txt_df = Player2_txt_df.fillna("-")
    
    
    with open(Player1_in, "r") as p1_in, open(Player2_in, "r") as p2_in, open(P1_optional, "r") as p1_opt, open(P2_optional, "r") as p2_opt:
        
        Player1_in = p1_in.read()
        Player2_in = p2_in.read()
        P1_optional = p1_opt.read()
        P2_optional = p2_opt.read()
        
    return Player1_txt_df, Player2_txt_df, Player1_in, Player2_in, P1_optional, P2_optional


def printer_for_double_boards(Player1_txt_df, Player2_txt_df, hidden = True):
    
    col_data = {"": np.arange(0, 11)}
    
    col_df = pd.DataFrame(col_data)
    concat_string = pd.concat([Player1_txt_df, col_df, Player2_txt_df], axis=1).to_string()
    
    returnie_string = ""
    for i, row in enumerate(concat_string.replace(" ", "").split("\n")):
        if i == 0:
            pass
        elif 1 <= i <=9:
            row = " ".join([c for c in row])
            row = list(row)
            row[21] = "\t\t"
            row = "".join(row)
            returnie_string += row+"\n"
        elif i == 10:
            row = " ".join([c for c in row])
            row = row.replace("1 0 ","10")
            row = list(row)
            row[21] = "\t\t"
            row = "".join(row)
            returnie_string += row+"\n"
    
    returnie_string = "  A B C D E F G H I J\t\t  A B C D E F G H I J\n" + returnie_string
    
    tab_str = "\t\t\t\t"
    hid_str = ""
    if hidden:
        hid_str = "Hidden "
        tab_str = "\t\t"
    
    returnie_string = "Player1's {}Board{}Player2's {}Board\n".format(hid_str, tab_str, hid_str) + returnie_string
    return returnie_string

def printer_for_double_ship(Player1_hit_dict, Player2_hit_dict):
    
    returnie_string = ""
    
    for ship_name in Player1_hit_dict.keys():
        value_list1 = Player1_hit_dict[ship_name]
        value_list2 = Player2_hit_dict[ship_name]
        
        x = 1
        y = 4
        if ship_name == "Carrier":
            x = 2
        elif ship_name == "Patrol Boat":
            y = 3
        
        returnie_string += ship_name + "\t" * x + " ".join(value_list1) + "\t" * y
        returnie_string += ship_name + "\t" * x + " ".join(value_list2) + "\n"
        
    return returnie_string
    
def check_if_any_sunk(Player_txt_df, a, b, old_current_value):
    
    current_value = Player_txt_df.loc[int(a)][b]
    index_b = Player_txt_df.columns.get_loc(b)
    
    #print(old_current_value)
    if old_current_value == "B":
        max_len = 4
        t = "Battleship"
    elif old_current_value == "D":
        max_len = 3
        t = "Destroyer"
    elif old_current_value == "S":
        max_len = 3
        t = "Submarine"
    elif old_current_value == "C":
        max_len = 5
        t = "Carrier"
    elif old_current_value == "P":
        max_len = 2
        t = "Patrol Boat"
    
    #u,d,l,r = "-","-","-","-"
    
    appendix = []
    appendix.append(current_value)
    
    #print(appendix)
    
    for i in range(1, max_len):
        try:
            u = Player_txt_df.loc[int(a) - i][index_b]
            
            if u == "-" or u == "O":
                break
            else:
                appendix.append(u)
        except:
            break
    
    for i in range(1, max_len):
        try:
            d = Player_txt_df.loc[int(a) + i][index_b]
            
            if d == "-" or d == "O":
                break
            else:
                appendix.append(d)
        except:
            break
    
    #print(appendix)
    # Yön değiştirdim
    if len(appendix) < max_len:
        appendix = []
        appendix.append(current_value)
    
    #print(appendix)
    
    for i in range(1, max_len):
        if len(appendix) == max_len: break
        try:
            l = Player_txt_df.loc[int(a)][index_b - i]
            
            capraz_sol_ust = Player_txt_df.loc[int(a) - 1][index_b - 1]
            
            #print("capraz", capraz_sol_ust)
            
            # boş değilse solunda carrier var yan yana, sola bakma geç, örnek spesifik kod.
            if capraz_sol_ust == "X" or capraz_sol_ust == "C":
                break
            
            #print("l", l)
            if l == "-" or l == "O":
                break
            else:
                appendix.append(l)
        except:
            break
    
    #print(appendix)
    
    if len(appendix) < max_len:
        for i in range(1, max_len):
            if len(appendix) == max_len: break
            try:
                r = Player_txt_df.loc[int(a)][index_b + i]
                
                if r == "-" or r == "O":
                    break
                else:
                    appendix.append(r)
            except:
                break
    
    #print(appendix)
    sunk = False
    
    if "P" in appendix or "D" in appendix or "B" in appendix or "C" in appendix or "S" in appendix:
        pass
    else:
        sunk = True
    
    return sunk, t
 

def check_if_all_sunk(Player1_hit_dict, Player2_hit_dict):
    
    allsunk1 = True
    allsunk2 = True
    
    #print(Player1_hit_dict)
    #print(Player2_hit_dict)
    
    for i, v in enumerate(Player1_hit_dict.values()):
        #print(i,v)
        if "-" in v:
            allsunk1 = False
    
    for i, v in enumerate(Player2_hit_dict.values()):
        #print(i,v)
        if "-" in v:
            allsunk2 = False
            
    return allsunk1, allsunk2


Player1_txt_df, Player2_txt_df, Player1_in, Player2_in, P1_optional, P2_optional = read_all_files()

returnie_string = printer_for_double_boards(Player1_txt_df, Player2_txt_df, False)
print(returnie_string)



output_file = open("Battleship.out", "w")

print("Battle of Ships Game\n", file=output_file)

Player1_hidden_df = Player1_txt_df.copy(deep=True)
Player1_hidden_df.loc[:,:] = "-"
Player2_hidden_df = Player2_txt_df.copy(deep=True)
Player2_hidden_df.loc[:,:] = "-"

#returnie_string = printer_for_double_boards(Player1_hidden_df, Player2_hidden_df)
#print(returnie_string)

Player1_hit_dict = {"Carrier"     : ["-"],
                    "Battleship"  : ["-", "-"],
                    "Destroyer"   : ["-"],
                    "Submarine"   : ["-"],
                    "Patrol Boat" : ["-", "-", "-", "-"]
                    }

Player2_hit_dict = {"Carrier"     : ["-"],
                    "Battleship"  : ["-", "-"],
                    "Destroyer"   : ["-"],
                    "Submarine"   : ["-"],
                    "Patrol Boat" : ["-", "-", "-", "-"]
                    }

#returnie_string = printer_for_double_ship(Player1_hit_dict, Player2_hit_dict)
#print(returnie_string)

Player1_moves = Player1_in.split(";")[:-1]
Player2_moves = Player2_in.split(";")[:-1]


round = 0
game_ends = False

round = 1
# Round loop
while(True):
    #print(round)
    # Player 1 move loop with exceptions
    print("Player1's Move\n", file=output_file)
    print("Round : {}\t\t\t\t\tGrid Size: 10x10\n".format(round), file=output_file)
    double_boards = printer_for_double_boards(Player1_hidden_df, Player2_hidden_df)
    print(double_boards, file=output_file)
    
    double_ship_info = printer_for_double_ship(Player1_hit_dict, Player2_hit_dict)
    print(double_ship_info, file=output_file)
    while True:
        ifbreak = False
        try:
            x = Player1_moves.pop(0)
            
            print("Enter your move: {}\n".format(x), file=output_file)
            
            a,b = x.split(",")
            
            #print(Player2_txt_df)
            #print("a,b ",a,b)
            current_value = Player2_txt_df.loc[int(a)][b]
            #print(current_value)
            
        except Exception as err:
            print("Some error. ", err, file=output_file)
            print("\n", file=output_file)
        else:
            ifbreak = True
        
        
        try:
            if current_value == "-":
                Player2_txt_df.loc[int(a)][b] = "O"
                Player2_hidden_df.loc[int(a)][b] = "O"
            elif current_value == "X" or current_value == "O":
                raise Exception
            else:
                Player2_txt_df.loc[int(a)][b] = "X"
                Player2_hidden_df.loc[int(a)][b] = "X"
                
                sunk, t = check_if_any_sunk(Player2_txt_df, a, b, current_value)
                
                if sunk:
                    #print("Battı kardeş battı, ", t)
                    """
                    if t == "Unknown":
                        if "-" in Player1_hit_dict["Destroyer"]:
                            t = "Destroyer"
                        elif "-" in Player1_hit_dict["Submarine"]:
                            t = "Submarine"
                    """
                    
                    if current_value == "B":
                        t = "Battleship"
                    elif current_value == "D":
                        t = "Destroyer"
                    elif current_value == "S":
                        t = "Submarine"
                    elif current_value == "C":
                        t = "Carrier"
                    elif current_value == "P":
                        t = "Patrol Boat"
                    
                    
                    try:
                        sign_list = Player2_hit_dict[t]
                        index_to_change = sign_list.index("-")
                        sign_list[index_to_change] = "X"
                        Player2_hit_dict[t] = sign_list
                    except Exception as err:
                        print("ifsunk 307: ", err, file=output_file)
                        print("\n", file=output_file)
                        
        except Exception as err:
            pass
    
        if ifbreak:
            break
        
    # Player 2 move loop with exceptions
    print("Player2's Move\n", file=output_file)
    print("Round : {}\t\t\t\t\tGrid Size: 10x10\n".format(round), file=output_file)
    double_boards = printer_for_double_boards(Player1_hidden_df, Player2_hidden_df)
    print(double_boards, file=output_file)
    
    double_ship_info = printer_for_double_ship(Player1_hit_dict, Player2_hit_dict)
    print(double_ship_info, file=output_file)
    while True:
        #print(round)
        ifbreak = False
        try:
            y = Player2_moves.pop(0)
            
            print("Enter your move: {}\n".format(y), file=output_file)
            
            c,d = y.split(",")
            
            #print(Player1_txt_df)
            #print("c,d ",c,d)
            current_value = Player1_txt_df.loc[int(c)][d]
            #print(current_value)
            
        except Exception as err:
            print("Some error. ", err, file=output_file)
            print("\n", file=output_file)
        else:
            ifbreak = True
            
            
        try:
            if current_value == "-":
                Player1_txt_df.loc[int(c)][d] = "O"
                Player1_hidden_df.loc[int(c)][d] = "O"
            elif current_value == "X" or current_value == "O":
                raise Exception
            else:
                Player1_txt_df.loc[int(c)][d] = "X"
                Player1_hidden_df.loc[int(c)][d] = "X"
                
                sunk, t = check_if_any_sunk(Player1_txt_df, c, d, current_value)
                
                if sunk:
                    #print("Battı kardeş battı, ", t)
                    
                    """
                    if t == "Unknown":
                        if "-" in Player1_hit_dict["Destroyer"]:
                            t = "Destroyer"
                        elif "-" in Player1_hit_dict["Submarine"]:
                            t = "Submarine"
                    """
                    
                    if current_value == "B":
                        t = "Battleship"
                    elif current_value == "D":
                        t = "Destroyer"
                    elif current_value == "S":
                        t = "Submarine"
                    elif current_value == "C":
                        t = "Carrier"
                    elif current_value == "P":
                        t = "Patrol Boat"
                    
                    try:
                        sign_list = Player1_hit_dict[t]
                        index_to_change = sign_list.index("-")
                        sign_list[index_to_change] = "X"
                        Player1_hit_dict[t] = sign_list
                    except:
                        pass
            
        except:
            pass
        
        if ifbreak:
            break
    
    round += 1
    
    #if round > 20:
        #break
    
    player1allsunk, player2allsunk = check_if_all_sunk(Player1_hit_dict, Player2_hit_dict)
    
    if player1allsunk and player2allsunk:
        print("It is a Draw!\n", file=output_file)
        print("Final Information\n", file=output_file)
        returnie_string = printer_for_double_boards(Player1_txt_df, Player2_txt_df, False)
        print(returnie_string, file=output_file)
        
        double_ship_info = printer_for_double_ship(Player1_hit_dict, Player2_hit_dict)
        print(double_ship_info, file=output_file)
        
        break
    elif player1allsunk:
        print("Player2 Wins!\n", file=output_file)
        print("Final Information\n", file=output_file)
        returnie_string = printer_for_double_boards(Player1_txt_df, Player2_txt_df, False)
        print(returnie_string, file=output_file)
        
        double_ship_info = printer_for_double_ship(Player1_hit_dict, Player2_hit_dict)
        print(double_ship_info, file=output_file)
        
        break
    elif player2allsunk:
        print("Player1 Wins!\n", file=output_file)
        print("Final Information\n", file=output_file)
        returnie_string = printer_for_double_boards(Player1_txt_df, Player2_txt_df, False)
        print(returnie_string, file=output_file)
        
        double_ship_info = printer_for_double_ship(Player1_hit_dict, Player2_hit_dict)
        print(double_ship_info, file=output_file)
        
        break


output_file.close()







"""
Player1's Move

Round : 1                    Grid Size: 10x10

{print_double_boards}

{print_double_dicts}

Enter your move: 1,I

Player2's Move

Round : 1                    Grid Size: 10x10

{print_double_boards}

{print_double_dicts}

Enter your move: 2,B
"""



